###### SET THE WORKING DIRECTORATE ####
setwd("H:\\Exam_practise_2025\\Big_Data_with_R")

## libraries
library()