## Setting the working directorate
setwd("H:\\Exam_practise_2025\\Big_Data_with_R")

## Loading the required libraries
library(tidyverse)
library(tidyselect)
library(tidyr)
library(ggplot2)
library(readr)
library(readxl)
library(data.table)

## Importing the data set
df <- read_excel("Bike_Sales_New.xlsx")
df_table <- as.data.table(df)
df_table %>% 
  view()

## Carrying out some exploratory data analysis on the data set
class(df_table)

df_table %>% 
  names()

df_table %>% 
  glimpse()

df_table[,head(df_table,10)] %>% 
  view()

## Extracting the Bike sales data for Canada,France, Australia,Germany,United Kingdom,United States from the dataset
df_Australia <- subset(df_table,Country %in% "Australia")
df_Australia[,head(df_Australia,10)] %>% view()

## Extracting those from France
df_France <- df_table[Country == "France"]
df_France[,head(df_France, 10)] %>% 
  view()

## Subsetting those from Germany
df_Germany <- df_table[Country == "Germany",]
df_table[,head(df_table, 10)] %>% 
  view()

## Extracting those from Canada
df_Canada <- subset(df_table,Country %in% "Canada")
df_Canada

## Subsetting by Age group
df_table$Age_Group %>% 
  table() %>%
  view()

## Subsetting using the list function to return results
# Month, Profit, Revenue
df_table[,list(Month,Profit,Revenue)][,head(df_table, 5)] %>% 
  view()

# Country, State, Revenue
df_table[,.(Country,State,Revenue)][,head(df_table, 10)] %>% 
  view()

## Extracting the numerical columns
cont <- df_table[,c("Year","Customer_Age","Cost","Unit_Cost","Profit","Revenue")]
cont[,head(cont,10)] %>% 
  view()

## Analysing the profit
Most_Profitable <-  df_table[which.max(df_table$Profit),][,c("Customer_Age","Country","State","Age_Group","Product_Category","Year","Product","Profit")]
Most_Profitable %>% 
  view()

## All the products whose profits are above 200
Profit_above_200 <- df_table[Profit >= 200,]
Profit_above_200 %>% 
  view()

## The least profitable product
Least_Profitable <- df_table[which.min(df_table$Profit),][,c("Customer_Age","Country","State","Age_Group","Product_Category","Year","Product","Profit")]
Least_Profitable %>% 
  view()

## Correlation between the day and profit
df_table[Profit > 300, ][,c("Year","Day","Profit")] %>% 
  view()

## Find the the mean revenue and profit
#Mean
mean(df_table$Revenue)  # Mean ---------> 144.8497
# Median
median(df_table$Revenue) # Median ------> 96

## Find he mean and median profits and Revenue by Customer_Gender
# Mean for Revenue
df_table[,mean(Revenue),by="Customer_Gender"] %>% # F --------> 142.2231
  view()                                          # M --------> 147.3307
 
# Mean for Profit
df_table[,mean(Profit),by="Customer_Gender"] %>%  # F -------> 83.23314
view()                                            # M -------> 86.65343

## Carrying out the summary statistics by Country and Age group
df_table[,mean(Revenue),by="Country"] %>% 
  view()

## By age group
df_table[,mean(Revenue),by="Age_Group"] %>% 
  view()

## Number of customers who purchase the products by Gender
df_table[,.(count = .N),by = "Customer_Gender"] %>% 
  view()

## Total Revenue from the different countries
# United States by Gender
df_table[Country == "United States",sum(Revenue),by="Customer_Gender"] %>% 
  view() 
df_table[Country == "United States",sum(Profit),] # Total_Profit ------> 2120455

## Germany
df_table[Country == "Germany",sum(Revenue),] # Total_Revenue  -------> 969140
df_table[Country == "Germany",sum(Profit),]  # Total_Profit -------> 969140 

## Analyzing the data by year
df_table$Year <- as.factor(df_table$Year)
class(df_table$Year)
# Then total Revenue and profit by year
df_table[,sum(Revenue),by="Year"] %>%  
      view()                           

df_table[,sum(Profit),by="Year"] %>% 
  view()

# Yer with the highest transactions
df_table[,.(count = .N),by = "Year"] %>% 
  view()

## Analyzing the data by Month
# Revenue
df_table[,sum(Revenue),by = "Month"] %>% 
  view()

# Profit
df_table[,sum(Profit),by = "Month"] %>% 
  view()

## The month with many transactions
df_table[,.(count = .N),by = "Month"] %>% 
  view()

## Analyzing the bike sales by Product Category
# Which Product category had the highest sales
df_table[,.(count = .N), by = "Product_Category"] %>% 
  view()

# Total Revenue from each product category
df_table[,sum(Revenue),by = "Product_Category"] %>% 
  view()

# Total Profit by Product Category
df_table[,sum(Profit),by = "Product_Category"] %>% 
  view()

## Analyze data by state
# Total revenue 
df_table[,sum(Revenue), by = "State"] %>% 
  view()

# Total profit from every state
df_table[,sum(Profit),by = "State"] %>% 
  view()

## Analyzing of the continuous data
sum(is.na(df_table))

## Dealing with outliers
boxplot(df_table$Unit_Cost)

## Function for a boxplot
box_plot <- function(data){
  #Set the number of columns in the plot layout
  columns <- names(data)
  # Set number of columns in the plot layout
  num_cols <- 3
  # Calculate the number of rows
  num_rows <- ceiling(length(columns) / num_cols)
  # Setting the plotting area
  par(mfrow = c(num_rows,num_cols))
  
  for (col in columns){
    if (is.numeric(data[[col]])){
      boxplot(data[[col]],col="lightblue",main=col,xlab =col,border = "black")
    }
  }
  par(mfrow = c(1,1))
}
box_plot(cont)
