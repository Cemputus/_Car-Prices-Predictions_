#### SETT THE WORKING DIRECTORATE #####
setwd("H:/Exam_practise_2025/Big_Data_with_R")

## LOADING THE LIBRARAIES
library(caTools)
library(MASS)
library(rpart.plot)
library(Hmisc)
library(caret)
library(car)
library(cvms)