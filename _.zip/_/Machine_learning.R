## SETTIN THE WORKING DIRECTORATE
setwd("H:\\Exam_practise_2025\\Big_Data_with_R")

## Loading the required libraries
library(tidyverse)
library(ggplot2)
library(data.table)
library(tidyr)

## Install the needed libraries
install.packages("Hmisc")
install.packages("ISLR")
installed.packages("ModelMetrics")
install.packages("car")
install.packages("nortes")


install.packages("installr")
install.packages("corrplot")
library(installr)
updateR()
## checking the available libraries
library(corrplot)

## loading the needed libraries ##
library(Boruta)
library(corrplot)
library(caret)
library(ggcorrplot)
library(olsrr)
library(ModelMetrices)
library(bestNormalize)
library(MASS)
library(rpart.plot)
library(caret)


### Handling missing values
## In tidyverse 
df1 <- read_excel("Student_performance1.xlsx")
df1 %>% 
  head() %>% 
  view()
## Checking for missing values
sum(is.na(df1))

## Checking for the incomplete cases
df1 %>% 
  filter(!complete.cases(.)) %>% 
  view()

## Checking the missing values in each column ##
colSums(is.na(df1)) %>% 
  view()

## Dealing with the missing values ##
## Categorical variables
df1 %>% 
  select(gender) %>% 
  table() %>% 
  view()
## dealing missing values in categoricals
df1$gender[is.na(df1$gender)] <- names(which.max(table(df1$gender)))
df1$gender[is.na(df1$gender)] <- mode(df1$gender[!is.na(df1$gender)])
colSums(is.na(df1))

## Dealing with mising values in numericals
## Checking thedistribution
box_plot <- function(data){
  for (col in names(data)){
    if (is.numeric(data[[col]])){
      hist(data[[col]])
    }
  }
}
box_plot(df1)

### PLOTTING IN SUBPLOTS
hist_plot <- function(data){
  ## Getting the columns
  columns = names(data)
  ## setting the columns in the plot
  num_cols = 3
  ## Setting the number of rows
  num_rows <- ceiling(length(columns) / num_cols)
  ## Setting the plotting area
  par(mfrow=c(num_rows,num_cols))
  ## Creating the loop
  for (col in columns){
    if (is.numeric(data[[col]])){
      hist(data[[col]])
    }
  }
  par(mfrow=c(1,1))
}
hist_plot(df1)

### IMPUTING WITH MEDIAN
## Without a function
df1$age[is.na(df1$age)] <- median(df1$age,na.rm = TRUE)

## With a function
deal_missing <- function(data){
  for (col in names(data)){
    if (is.numeric(data[[col]])){
      data[[col]][is.na(data[[col]])] <- median(data[[col]],na.rm = TRUE)
    }
  }
  return(data)
}
deal_missing(df1)
colSums(is.na(df1))

## Checking for outliers
# function
check_outliers <- function(data){
  columns <- names(data)
  num_cols <- 3
  num_rows <- ceiling(length(columns) / num_cols)
  par(mfrow = c(num_rows,num_cols))
  for (col in columns){
    if (is.numeric(data[[col]])){
      boxplot(data[[col]],col="lightblue",main = col)
    }
  }
  par(mfrow = c(1,1))
}
check_outliers(df1)

## Dealing with the missing values using the IQR
 ## age
IQR(df1$age)  ## IQR ----------> 11

summary(df1$age) # q1 ----> 24.00, q2 -------> 35.00

remove_outlier <- function(data) {
  for (col in names(data)) {
    if (is.numeric(data[[col]])) {
      # Calculate Q1, Q3, and IQR
      Q1 <- quantile(data[[col]], 0.25, na.rm = TRUE)
      Q3 <- quantile(data[[col]], 0.75, na.rm = TRUE)
      IQR <- Q3 - Q1
      
      # Define limits
      lower_limit <- Q1 - 1.5 * IQR
      upper_limit <- Q3 + 1.5 * IQR
      
      # Remove outliers
      data <- data[data[[col]] >= lower_limit & data[[col]] <= upper_limit, ]
    }
  }
  return(data)
}

# Example usage
df1_cleaned <- remove_outlier(df1)
# Check the result
check_outliers(df1_cleaned)
