##### SETTING THEWORKING DIRECTORATE ######
setwd("H:/Exam_practise_2025/Big_Data_with_R")

## Loading the needed libraries
library(tidyverse)
library(tidyr)
library(readr)
library(readxl)
library(data.table)
library(ggplot2)
##ML LIBRARIES
library(caTool)
library(rpart.plot)
library(caret)
library(car)
library(cards)
library(MASS)
library(cvms)

### LOADING AND IMPORTING THE DATASET
data <- read.csv("Loan_Approval_Data.csv")