## -------------------------
## Q12 ANALYSIS: BIKE SALES
## -------------------------

## A. SETTING THE ENVIRONMENT ------------------------

## Set working directory -----
setwd("C:/Users/EMMANUEL NSUBUGA/OneDrive/Documents/Data_Science/year2/semester 2/Big Data -R/trial")
getwd()

## Load required libraries -----
if (!require("psych")) install.packages("psych")
if (!require("writexl")) install.packages("writexl")
if (!require("reshape2")) install.packages("reshape2")
library(reshape2)
library(ggplot2)
library(tidyr)
library(tidyverse)
library(ggplot2)
library(data.table)
library(tidyselect)
library(readxl)
library(readr)
library(psych)
library(writexl)

## B. DATA TRANSFORMATION AND CLEANING ------------------------

## Read the Excel file -----
df <- read_excel("Bike_Sales_New.xlsx")
View(df)

## Explore structure and dimension -----
names(df)
dim(df)
str(df)
glimpse(df)
class(df)

## Check for duplicates and remove them -----
sum(duplicated(df))
df <- df[!duplicated(df), ]

## Check for missing values -----
missing_values <- sapply(df, function(x) sum(is.na(x)))
print(missing_values)

## checking for data distribution
hist(df$Profit)

histogram <- function(df){
  par(mfrow = c(2, 2))
  for (colname in names(df)) {
    if (is.numeric(df[[colname]])) {
      hist(df[[colname]], 
              main = paste("Histogram of", colname), 
              xlab = colname, 
              col = "skyblue")
    }
  }
  par(mfrow = c(1, 1))
}
histogram(df)



## Impute missing values -----
impute_mean <- function(x) replace(x, is.na(x), mean(x, na.rm = TRUE))
impute_median <- function(x) replace(x, is.na(x), median(x, na.rm = TRUE))
impute_mode <- function(x) {
  modal_value <- names(sort(table(x), decreasing = TRUE))[1]
  replace(x, is.na(x), modal_value)
}

## Apply imputation -----
if (is.numeric(df$Profit)) {
  df$Profit <- impute_mean(df$Profit)
}
df$Country <- impute_mode(df$Country)

## C. OUTLIER DETECTION AND REMOVAL ------------------------



## Boxplot before removing outliers -----
outlier_boxplot <- function(df){
  par(mfrow = c(2, 2))
  for (colname in names(df)) {
    if (is.numeric(df[[colname]])) {
      boxplot(df[[colname]], 
              main = paste("Boxplot of", colname), 
              xlab = colname, 
              col = "skyblue")
    }
  }
  par(mfrow = c(1, 1))
}
outlier_boxplot(df)

## Remove outliers using IQR -----
removing_outliers <- function(df){
  for (colname in names(df)) {
    if (is.numeric(df[[colname]])) {
      q1 <- quantile(df[[colname]], 0.25, na.rm = TRUE)
      q3 <- quantile(df[[colname]], 0.75, na.rm = TRUE)
      IQR <- q3 - q1
      lower <- q1 - 1.5 * IQR
      upper <- q3 + 1.5 * IQR
      df <- df[df[[colname]] >= lower & df[[colname]] <= upper, ]
    }
  }
  return(df)
}

df_cleaned <- removing_outliers(df)

## Boxplot after removing outliers -----
outlier_boxplot(df_cleaned)

## D. SAVE TRANSFORMED DATASET ------------------------

save(df_cleaned, file = "Q12.RData")
write_xlsx(df_cleaned, "Q12.xlsx")

## E. DESCRIPTIVE STATISTICS ------------------------

selected_vars <- df_cleaned %>% 
  select(Date, Month, Customer_Age, Customer_Gender, Age_Group, 
         State, Sub_Category, Country, Cost, Unit_Cost, Unit_Price, Profit, Revenue)

describe(selected_vars) %>% 
  view()

summary(selected_vars) %>% 
  view()

## F. RELATIONSHIPS BETWEEN VARIABLES ------------------------

## 1. Continuous vs Continuous: Correlation -----
cor_test <- cor.test(df_cleaned$Unit_Cost, df_cleaned$Unit_Price)
print(cor_test)

ggplot(df_cleaned, aes(x = Unit_Cost , y = Unit_Price)) +
  geom_point(color = "blue") +
  geom_smooth(method = "lm", color = "red") +
  ggtitle("Relationship between Unit_Cost and Unit_Price")


cor_test <- cor.test(df_cleaned$Cost, df_cleaned$Profit)
print(cor_test)

ggplot(df_cleaned, aes(x = Cost , y = Profit)) +
  geom_point(color = "blue") +
  geom_smooth(method = "lm", color = "red") +
  ggtitle("Relationship between Cost and Profit")

## 2. Categorical + Continuous: ANOVA & Boxplot -----
ggplot(df_cleaned, aes(x = Product, y = Customer_Age, fill = Age_Group)) +
  geom_boxplot() +
  ggtitle("Product Purchased by Customer Age and Age Group")

anova_test <- aov(Profit ~ Product * Country, data = df_cleaned)
summary(anova_test)



# Select only numeric columns without using sapply
numeric_data <- Filter(is.numeric, df_cleaned)

# Compute correlation matrix
cor_matrix <- round(cor(numeric_data, use = "complete.obs"), 2) %>% 
  view()



# Melt the matrix to long format
melted_cor <- melt(as.data.frame(cor_matrix), varnames = c("Profit", "Revenue"))

# Create heatmap
ggplot(data = melted_cor, aes(x = Profit, y = Revenue, fill = Cost)) +
  geom_tile(color = "white") +
  geom_text(aes(label = value), size = 4) +
  scale_fill_gradient2(low = "red", high = "green", mid = "white", 
                       midpoint = 0, limit = c(-1, 1), space = "Lab", 
                       name = "Correlation") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                   size = 12, hjust = 1)) +
  labs(title = "Heatmap of Numeric Variable Correlations",
       x = "Profit", y = "Revenue")




# 1. Select only the numeric columns from your list
numeric_vars <- df_cleaned[, c("Day", "Month", "Year", "Customer_Age",
                               "Order_Quantity", "Unit_Cost", "Unit_Price",
                               "Profit", "Cost", "Revenue")]

# 2. Compute correlation matrix
cor_matrix <- round(cor(numeric_vars, use = "complete.obs"), 2)

# 3. Melt correlation matrix to long format
melted_cor <- melt(cor_matrix)
colnames(melted_cor) <- c("Variable1", "Variable2", "Correlation")

# 4. Create heatmap plot
ggplot(data = melted_cor, aes(x = Variable1, y = Variable2, fill = Correlation)) +
  geom_tile(color = "white") +
  geom_text(aes(label = round(Correlation, 2)), size = 4) +
  scale_fill_gradient2(low = "red", high = "green", mid = "skyblue",
                       midpoint = 0, limit = c(-1, 1), space = "Lab",
                       name = "Correlation") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, size = 12, hjust = 1),
        axis.text.y = element_text(size = 12)) +
  labs(title = "Heatmap of Correlations Among Selected Variables",
       x = "Variables", y = "Variables")


names(df_cleaned)
## G. SUPERVISED LEARNING ------------------------

## 1. Simple Linear Regression -----
simple_model <- lm(Profit ~ Revenue, data = df_cleaned)
summary(simple_model)

ggplot(df_cleaned, aes(x = Revenue, y = Profit)) +
  geom_point(color = "darkgreen") +
  geom_smooth(method = "lm", se = TRUE, color = "red") +
  ggtitle("Simple Linear Regression: Profit vs Revenue")

## 2. Multiple Linear Regression -----
multi_model <- lm(Profit ~ Revenue + Unit_Cost + Customer_Age + Month, data = df_cleaned)
summary(multi_model)

par(mfrow = c(2, 2))
plot(multi_model)
par(mfrow = c(1, 1))
