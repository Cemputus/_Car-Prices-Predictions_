## ------------------------- ##
## Q12 ANALYSIS: DIAMOND PRICES AND PERCEPTIONS
## ------------------------- ##

## A. SETTING THE ENVIRONMENT ------------------------

# Set the working directory to where the dataset is stored
# This ensures R knows where to read and write files
setwd("C:/Users/EMMANUEL NSUBUGA/OneDrive/Documents/Data_Science/year2/semester 2/Big Data -R/trial")
# Verify the working directory
getwd()

# Load required libraries for data manipulation, visualization, and analysis
# Check if packages are installed; install if not
if (!require("psych")) install.packages("psych") # For descriptive statistics
if (!require("writexl")) install.packages("writexl") # For exporting to Excel
if (!require("reshape2")) install.packages("reshape2") # For reshaping data
library(reshape2) # For melting correlation matrices
library(ggplot2) # For advanced visualizations
library(tidyr) # For data tidying
library(tidyverse) # For data manipulation and visualization
library(data.table) # For efficient data handling
library(readxl) # For reading Excel files
library(readr) # For reading various data formats
library(psych) # For statistical summaries
library(writexl) # For writing Excel files

## B. DATA TRANSFORMATION AND CLEANING ------------------------

# Read the diamond dataset from an Excel file
# Assumes the dataset is saved as "Diamond_Data.xlsx"
df <- read_excel("PricingOfDiamonds.xlsx")
# Display the dataset in R's viewer for initial inspection
View(df)

# Explore the dataset's structure to understand its variables and types
# Check column names
names(df)
# Check dimensions (rows and columns)
dim(df)
# Check structure (data types and sample values)
str(df)
# Glimpse for a concise summary of columns and values
glimpse(df)
# Confirm the class of the object (should be a data frame or tibble)
class(df)

# Check for duplicate rows to ensure data integrity
# Sum the number of duplicated rows
sum(duplicated(df))
# Remove duplicates, keeping only unique rows
df <- df[!duplicated(df), ]

# Check for missing values in each column
# This helps identify columns that need imputation
missing_values <- sapply(df, function(x) sum(is.na(x)))
# Print the count of missing values per column
print(missing_values)

# Visualize the distribution of numeric variables using histograms
# This helps understand data spread and identify skewness or outliers
histogram <- function(df){
  # Set up a 2x2 plot grid for multiple histograms
  par(mfrow = c(2, 2))
  # Loop through each column
  for (colname in names(df)) {
    # Only plot histograms for numeric columns
    if (is.numeric(df[[colname]])) {
      hist(df[[colname]], 
           main = paste("Histogram of", colname), # Title with column name
           xlab = colname, # X-axis label
           col = "lightgreen") # Use light green for visual clarity
    }
  }
  # Reset plot layout to single plot
  par(mfrow = c(1, 1))
}
# Call the histogram function
histogram(df)

# Define functions for imputing missing values
# Mean imputation for numeric variables
impute_mean <- function(x) replace(x, is.na(x), mean(x, na.rm = TRUE))
# Median imputation for numeric variables (alternative)
impute_median <- function(x) replace(x, is.na(x), median(x, na.rm = TRUE))
# Mode imputation for categorical variables
impute_mode <- function(x) {
  # Identify the most frequent value
  modal_value <- names(sort(table(x), decreasing = TRUE))[1]
  # Replace missing values with the mode
  replace(x, is.na(x), modal_value)
}

# Apply imputation to key columns
# Impute price with mean to maintain central tendency
if (is.numeric(df$price)) {
  df$price <- impute_mean(df$price)
}
# Impute carat with mean for consistency
if (is.numeric(df$carat)) {
  df$carat <- impute_mean(df$carat)
}
# Impute categorical variables with mode to preserve distribution
df$cut <- impute_mode(df$cut)
df$colour <- impute_mode(df$colour)
df$clarity <- impute_mode(df$clarity)
df$P <- impute_mode(df$P)
df$PC <- impute_mode(df$PC)

## checking for missing values again 
sapply(df, function(x) sum(is.na(x)))
## C. OUTLIER DETECTION AND REMOVAL ------------------------

# Visualize outliers using boxplots before removal
# Boxplots help identify extreme values in numeric columns
outlier_boxplot <- function(df){
  # Set up a 2x2 plot grid
  par(mfrow = c(2, 2))
  # Loop through columns
  for (colname in names(df)) {
    # Only plot boxplots for numeric columns
    if (is.numeric(df[[colname]])) {
      boxplot(df[[colname]], 
              main = paste("Boxplot of", colname), # Title with column name
              xlab = colname, # X-axis label
              col = "lightgreen") # Use light green for consistency
    }
  }
  # Reset plot layout
  par(mfrow = c(1, 1))
}
# Call the boxplot function
outlier_boxplot(df)

# Define a function to remove outliers using the IQR method
removing_outliers <- function(df){
  # Loop through each column
  for (colname in names(df)) {
    # Only process numeric columns
    if (is.numeric(df[[colname]])) {
      # Calculate Q1 (25th percentile) and Q3 (75th percentile)
      q1 <- quantile(df[[colname]], 0.25, na.rm = TRUE)
      q3 <- quantile(df[[colname]], 0.75, na.rm = TRUE)
      # Calculate Interquartile Range (IQR)
      IQR <- q3 - q1
      # Define lower and upper bounds for outliers
      lower <- q1 - 1.5 * IQR
      upper <- q3 + 1.5 * IQR
      # Keep only rows within bounds
      df <- df[df[[colname]] >= lower & df[[colname]] <= upper, ]
    }
  }
  # Return the cleaned dataset
  return(df)
}

# Apply outlier removal
# Note: Be cautious, as some high prices or carats may be valid
df_cleaned <- removing_outliers(df)

# Visualize boxplots after outlier removal to confirm changes
outlier_boxplot(df_cleaned)

## D. SAVE TRANSFORMED DATASET ------------------------

# Save the cleaned dataset as an RData file for future use
save(df_cleaned, file = "Diamond_Q12.RData")
# Export the cleaned dataset to Excel for external use
write_xlsx(df_cleaned, "Diamond_Q12.xlsx")

## E. DESCRIPTIVE STATISTICS ------------------------

# Select key variables for descriptive analysis
# Focus on variables relevant to price and perceptions
selected_vars <- df_cleaned %>% 
  select(carat, cut, colour, clarity, depth, price, x, y, P, PC)

# Compute descriptive statistics (mean, median, SD, etc.) using psych
# View results in a table
describe(selected_vars) %>% 
  View()

# Generate a summary of selected variables (min, max, quartiles)
# View results for quick inspection
summary(selected_vars) %>% 
  View()

## F. RELATIONSHIPS BETWEEN VARIABLES ------------------------

# 1. Continuous vs Continuous: Correlation Analysis
# Test correlation between carat and price
# Carat is expected to strongly influence price
cor_test <- cor.test(df_cleaned$carat, df_cleaned$price)
# Print correlation coefficient and p-value
print(cor_test)

# Visualize carat vs price relationship
ggplot(df_cleaned, aes(x = carat, y = price)) +
  geom_point(color = "blue") + # Scatter plot points
  geom_smooth(method = "lm", color = "red") + # Add linear regression line
  ggtitle("Relationship between Carat and Price") # Title

# Test correlation between depth and price
# Depth may have a weaker relationship with price
cor_test <- cor.test(df_cleaned$depth, df_cleaned$price)
print(cor_test)

# Visualize depth vs price relationship
ggplot(df_cleaned, aes(x = depth, y = price)) +
  geom_point(color = "blue") +
  geom_smooth(method = "lm", color = "red") +
  ggtitle("Relationship between Depth and Price")

# 2. Categorical + Continuous: ANOVA & Boxplot
# Explore how price varies by cut and clarity
# Boxplot visualizes distribution and outliers
ggplot(df_cleaned, aes(x = cut, y = price, fill = clarity)) +
  geom_boxplot() +
  ggtitle("Price by Cut and Clarity") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) # Rotate x-axis labels

# Perform ANOVA to test if price differs significantly by cut and clarity
anova_test <- aov(price ~ cut * clarity, data = df_cleaned)
# Summarize ANOVA results
summary(anova_test)

# Compute correlation matrix for numeric variables
# Focus on carat, depth, price, x (price/carat), y (price/depth)
numeric_data <- df_cleaned %>% 
  select(carat, depth, price, x, y)

# Calculate Pearson correlation, rounding to 2 decimal places
cor_matrix <- round(cor(numeric_data, use = "complete.obs"), 2)
# View the correlation matrix
View(cor_matrix)

# Create a heatmap to visualize correlations
# Melt the correlation matrix to long format for ggplot
melted_cor <- melt(cor_matrix)
# Rename columns for clarity
colnames(melted_cor) <- c("Variable1", "Variable2", "Correlation")

# Plot heatmap
ggplot(data = melted_cor, aes(x = Variable1, y = Variable2, fill = Correlation)) +
  geom_tile(color = "white") + # Tiles for correlation values
  geom_text(aes(label = round(Correlation, 2)), size = 4) + # Display values
  scale_fill_gradient2(low = "red", high = "green", mid = "skyblue",
                       midpoint = 0, limit = c(-1, 1), space = "Lab",
                       name = "Correlation") + # Color gradient
  theme_minimal() + # Minimal theme for clarity
  theme(axis.text.x = element_text(angle = 45, vjust = 1, size = 12, hjust = 1),
        axis.text.y = element_text(size = 12)) + # Adjust text
  labs(title = "Heatmap of Correlations Among Numeric Variables",
       x = "Variables", y = "Variables")

## G. EXPLORING PERCEPTIONS (P and PC) ------------------------

# Analyze initial price perceptions (P)
# Bar plot to show distribution of perception categories
ggplot(df_cleaned, aes(x = P, fill = P)) +
  geom_bar() + # Bar plot
  ggtitle("Distribution of Initial Price Perceptions (P)") +
  theme_minimal() +
  scale_fill_manual(values = c("Positive" = "green", "Negative" = "red", 
                               "SP" = "lightgreen", "SN" = "pink", "NR" = "grey")) # Custom colors

# Analyze changed price perceptions (PC)
# Bar plot to show distribution after understanding quality
ggplot(df_cleaned, aes(x = PC, fill = PC)) +
  geom_bar() +
  ggtitle("Distribution of Changed Price Perceptions (PC)") +
  theme_minimal() +
  scale_fill_manual(values = c("Positive" = "green", "Negative" = "red", 
                               "SP" = "lightgreen", "SN" = "pink", "NR" = "grey"))

# Cross-tabulate initial (P) vs changed (PC) perceptions
# This helps see if perceptions shift (e.g., Negative to Positive)
perception_table <- table(df_cleaned$P, df_cleaned$PC)
# Print the table
print(perception_table)

# Visualize P vs PC relationship with a mosaic plot
# Mosaic plot shows proportions and relationships
mosaicplot(perception_table, main = "Initial vs Changed Perceptions", color = TRUE)

# Explore perceptions by diamond quality (cut)
# Bar plot to see if higher-quality cuts influence initial perceptions
ggplot(df_cleaned, aes(x = cut, fill = P)) +
  geom_bar(position = "dodge") + # Side-by-side bars
  ggtitle("Initial Perceptions by Diamond Cut") +
  theme_minimal()

# Bar plot for changed perceptions by cut
# Tests if understanding cut quality changes perceptions
ggplot(df_cleaned, aes(x = cut, fill = PC)) +
  geom_bar(position = "dodge") +
  ggtitle("Changed Perceptions by Diamond Cut") +
  theme_minimal()

## H. SUPERVISED LEARNING ------------------------

# 1. Simple Linear Regression
# Model price as a function of carat (key predictor)
simple_model <- lm(price ~ carat, data = df_cleaned)
# Summarize model results (coefficients, R-squared, p-values)
summary(simple_model)

# Visualize the simple regression
ggplot(df_cleaned, aes(x = carat, y = price)) +
  geom_point(color = "darkblue") + # Scatter plot
  geom_smooth(method = "lm", se = TRUE, color = "red") + # Regression line with confidence interval
  ggtitle("Simple Linear Regression: Price vs Carat")

# 2. Multiple Linear Regression
# Include multiple predictors to model price
multi_model <- lm(price ~ carat + depth + x + y, data = df_cleaned)
# Summarize model results
summary(multi_model)

# Diagnostic plots for multiple regression
# Check assumptions (linearity, normality, homoscedasticity)
par(mfrow = c(2, 2))
plot(multi_model)
par(mfrow = c(1, 1))

## I. HYPOTHESIS TESTING ------------------------

# Test the hypothesis: Perceptions change after understanding quality
# Chi-squared test for independence between P and PC
chisq_test <- chisq.test(perception_table)
# Print test results (p-value, statistic)
print(chisq_test)

# Logistic regression to predict positive perception change
# Convert PC to binary: 1 for Positive/SP, 0 for Negative/SN/NR
df_cleaned$PC_binary <- ifelse(df_cleaned$PC %in% c("Positive", "SP"), 1, 0)

# Fit logistic regression model
# Use diamond qualities to predict likelihood of positive perception change
logit_model <- glm(PC_binary ~ carat + cut + clarity + colour, 
                   data = df_cleaned, family = "binomial")
# Summarize model results (coefficients, significance)
summary(logit_model)
