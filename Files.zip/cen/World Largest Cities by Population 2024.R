## ------------------------- 
## Q12 ANALYSIS: CITY POPULATION 
## -------------------------

## A. SETTING THE ENVIRONMENT ------------------------

## Set working directory -----
setwd("C:/Users/EMMANUEL NSUBUGA/OneDrive/Documents/Data_Science/year2/semester 2/Big Data -R/trial")
getwd()

## Load required libraries -----
if (!require("psych")) install.packages("psych")
if (!require("writexl")) install.packages("writexl")
if (!require("reshape2")) install.packages("reshape2")
library(reshape2)
library(ggplot2)
library(tidyr)
library(tidyverse)
library(data.table)
library(readr)
library(psych)
library(writexl)

## B. DATA TRANSFORMATION AND CLEANING ------------------------

## Read the CSV file -----
df <- read_csv("City_Population.csv")
View(df)

## Explore structure and dimension -----
names(df)
dim(df)
str(df)
glimpse(df)
class(df)

## Check for duplicates and remove them -----
sum(duplicated(df))
df <- df[!duplicated(df), ]

## Check for missing values -----
missing_values <- sapply(df, function(x) sum(is.na(x)))
print(missing_values)

## Checking for data distribution -----
hist(df$`Population (2024)`, main = "Histogram of Population (2024)", xlab = "Population (2024)", col = "skyblue")
hist(df$`Growth Rate`, main = "Histogram of Growth Rate", xlab = "Growth Rate", col = "skyblue")

histogram <- function(df){
  par(mfrow = c(2, 2))
  for (colname in names(df)) {
    if (is.numeric(df[[colname]])) {
      hist(df[[colname]], 
           main = paste("Histogram of", colname), 
           xlab = colname, 
           col = "skyblue")
    }
  }
  par(mfrow = c(1, 1))
}
histogram(df)

## Impute missing values -----
impute_mean <- function(x) replace(x, is.na(x), mean(x, na.rm = TRUE))
impute_median <- function(x) replace(x, is.na(x), median(x, na.rm = TRUE))
impute_mode <- function(x) {
  modal_value <- names(sort(table(x), decreasing = TRUE))[1]
  replace(x, is.na(x), modal_value)
}

## Apply imputation -----
if (is.numeric(df$`Population (2024)`)) {
  df$`Population (2024)` <- impute_mean(df$`Population (2024)`)
}
if (is.numeric(df$`Growth Rate`)) {
  df$`Growth Rate` <- impute_mean(df$`Growth Rate`)
}
df$Country <- impute_mode(df$Country)

## C. OUTLIER DETECTION AND REMOVAL ------------------------

## Boxplot before removing outliers -----
outlier_boxplot <- function(df){
  par(mfrow = c(2, 2))
  for (colname in names(df)) {
    if (is.numeric(df[[colname]])) {
      boxplot(df[[colname]], 
              main = paste("Boxplot of", colname), 
              xlab = colname, 
              col = "skyblue")
    }
  }
  par(mfrow = c(1, 1))
}
outlier_boxplot(df)

## Remove outliers using IQR -----
removing_outliers <- function(df){
  for (colname in names(df)) {
    if (is.numeric(df[[colname]])) {
      q1 <- quantile(df[[colname]], 0.25, na.rm = TRUE)
      q3 <- quantile(df[[colname]], 0.75, na.rm = TRUE)
      IQR <- q3 - q1
      lower <- q1 - 1.5 * IQR
      upper <- q3 + 1.5 * IQR
      df <- df[df[[colname]] >= lower & df[[colname]] <= upper, ]
    }
  }
  return(df)
}

df_cleaned <- removing_outliers(df)

## Boxplot after removing outliers -----
outlier_boxplot(df_cleaned)

## D. SAVE TRANSFORMED DATASET ------------------------

save(df_cleaned, file = "Q12_Population.RData")
write_xlsx(df_cleaned, "Q12_Population.xlsx")

## E. DESCRIPTIVE STATISTICS ------------------------

selected_vars <- df_cleaned %>% 
  select(City, Country, `Population (2024)`, `Population (2023)`, `Growth Rate`)

describe(selected_vars) %>% 
  view()

summary(selected_vars) %>% 
  view()

## F. RELATIONSHIPS BETWEEN VARIABLES ------------------------

## 1. Continuous vs Continuous: Correlation -----
cor_test <- cor.test(df_cleaned$`Population (2023)`, df_cleaned$`Population (2024)`)
print(cor_test)

ggplot(df_cleaned, aes(x = `Population (2023)`, y = `Population (2024)`)) +
  geom_point(color = "blue") +
  geom_smooth(method = "lm", color = "red") +
  ggtitle("Relationship between Population (2023) and Population (2024)")

cor_test <- cor.test(df_cleaned$`Population (2024)`, df_cleaned$`Growth Rate`)
print(cor_test)

ggplot(df_cleaned, aes(x = `Population (2024)`, y = `Growth Rate`)) +
  geom_point(color = "blue") +
  geom_smooth(method = "lm", color = "red") +
  ggtitle("Relationship between Population (2024) and Growth Rate")

## 2. Categorical + Continuous: ANOVA & Boxplot -----
ggplot(df_cleaned, aes(x = Country, y = `Population (2024)`)) +
  geom_boxplot() +
  ggtitle("Population (2024) by Country") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

anova_test <- aov(`Population (2024)` ~ Country, data = df_cleaned)
summary(anova_test)

## Correlation matrix for numeric variables -----
numeric_data <- Filter(is.numeric, df_cleaned)
cor_matrix <- round(cor(numeric_data, use = "complete.obs"), 2) %>% 
  view()

## Melt the matrix to long format -----
melted_cor <- melt(cor_matrix)
colnames(melted_cor) <- c("Variable1", "Variable2", "Correlation")

## Create heatmap plot -----
ggplot(data = melted_cor, aes(x = Variable1, y = Variable2, fill = Correlation)) +
  geom_tile(color = "white") +
  geom_text(aes(label = round(Correlation, 2)), size = 4) +
  scale_fill_gradient2(low = "red", high = "green", mid = "skyblue",
                       midpoint = 0, limit = c(-1, 1), space = "Lab",
                       name = "Correlation") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, size = 12, hjust = 1),
        axis.text.y = element_text(size = 12)) +
  labs(title = "Heatmap of Correlations Among Numeric Variables",
       x = "Variables", y = "Variables")

## G. SUPERVISED LEARNING ------------------------

## 1. Simple Linear Regression -----
simple_model <- lm(`Population (2024)` ~ `Population (2023)`, data = df_cleaned)
summary(simple_model)

ggplot(df_cleaned, aes(x = `Population (2023)`, y = `Population (2024)`)) +
  geom_point(color = "darkgreen") +
  geom_smooth(method = "lm", se = TRUE, color = "red") +
  ggtitle("Simple Linear Regression: Population (2024) vs Population (2023)")

## 2. Multiple Linear Regression -----
multi_model <- lm(`Population (2024)` ~ `Population (2023)` + `Growth Rate`, data = df_cleaned)
summary(multi_model)

par(mfrow = c(2, 2))
plot(multi_model)
par(mfrow = c(1, 1))