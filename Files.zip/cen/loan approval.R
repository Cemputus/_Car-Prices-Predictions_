## LOAN APPROVAL ANALYSIS ##

setwd("YOUR/WORKING/DIRECTORY")  
getwd()

## Install required libraries manually (uncomment if not already installed)
# install.packages("psych")
# install.packages("writexl")
# install.packages("reshape2")
# install.packages("ggplot2")
# install.packages("tidyr")
# install.packages("tidyverse")
# install.packages("data.table")
# install.packages("tidyselect")
# install.packages("readxl")
# install.packages("readr")

## Load required libraries
library(psych)
library(writexl)
library(reshape2)
library(ggplot2)
library(tidyr)
library(tidyverse)
library(data.table)
library(tidyselect)
library(readxl)
library(readr)

## B. DATA TRANSFORMATION AND CLEANING 
## Read the dataset (assuming it’s saved as a CSV file)
# Save the provided data as 'loan_data.csv' in your working directory
df <- read_csv("loan_data.csv")

## Explore structure and dimension
names(df)
dim(df)
str(df)
glimpse(df)
class(df)

## Check for duplicates and remove them
sum(duplicated(df))
df <- df[!duplicated(df), ]

## Check for missing values
missing_values <- colSums(is.na(df))
print("Missing Values:")
print(missing_values)

## Plot histogram for numeric variables
histogram <- function(data) {
  numeric_cols <- c("ApplicantIncome", "CoapplicantIncome", "LoanAmount", "Loan_Amount_Term")
  par(mfrow = c(2, 2))
  for (colname in numeric_cols) {
    hist(data[[colname]], 
         main = paste("Histogram of", colname), 
         xlab = colname, 
         col = "skyblue")
  }
  par(mfrow = c(1, 1))
}
histogram(df)

## Impute missing values
impute_mean <- function(x) replace(x, is.na(x), mean(x, na.rm = TRUE))
impute_median <- function(x) replace(x, is.na(x), median(x, na.rm = TRUE))
impute_mode <- function(x) {
  modal_value <- names(sort(table(x), decreasing = TRUE))[1]
  replace(x, is.na(x), modal_value)
}

## Apply imputation for relevant columns
numeric_cols <- c("ApplicantIncome", "CoapplicantIncome", "LoanAmount", "Loan_Amount_Term")
categorical_cols <- c("Gender", "Married", "Dependents", "Education", "Self_Employed", 
                      "Credit_History", "Property_Area", "Loan_Status")

for (col in numeric_cols) {
  if (sum(is.na(df[[col]])) > 0) {
    df[[col]] <- impute_median(df[[col]])  # Using median for financial data to avoid skew
  }
}
for (col in categorical_cols) {
  if (sum(is.na(df[[col]])) > 0) {
    df[[col]] <- impute_mode(df[[col]])
  }
}

## C. OUTLIER DETECTION AND REMOVAL ------------------------

## Boxplot before removing outliers
outlier_boxplot <- function(data, cols) {
  par(mfrow = c(2, 2))
  for (colname in cols) {
    boxplot(data[[colname]], 
            main = paste("Boxplot of", colname), 
            xlab = colname, 
            col = "skyblue")
  }
  par(mfrow = c(1, 1))
}
outlier_boxplot(df, numeric_cols)

## Remove outliers using IQR
removing_outliers <- function(data, cols) {
  for (colname in cols) {
    q1 <- quantile(data[[colname]], 0.25, na.rm = TRUE)
    q3 <- quantile(data[[colname]], 0.75, na.rm = TRUE)
    IQR <- q3 - q1
    lower <- q1 - 1.5 * IQR
    upper <- q3 + 1.5 * IQR
    data <- data[data[[colname]] >= lower & data[[colname]] <= upper, ]
  }
  return(data)
}

df_cleaned <- removing_outliers(df, numeric_cols)

## Boxplot after removing outliers
outlier_boxplot(df_cleaned, numeric_cols)

## D. SAVE TRANSFORMED DATASET ------------------------

save(df_cleaned, file = "Loan_Cleaned.RData")
write_xlsx(df_cleaned, "Loan_Cleaned.xlsx")

## E. DESCRIPTIVE STATISTICS ------------------------

selected_vars <- df_cleaned %>% 
  select(ApplicantIncome, CoapplicantIncome, LoanAmount, Loan_Amount_Term, 
         Gender, Married, Education, Credit_History, Property_Area, Loan_Status)

psych::describe(selected_vars[sapply(selected_vars, is.numeric)])  # Numeric variables only
summary(selected_vars)

## F. RELATIONSHIPS BETWEEN VARIABLES ------------------------

## 1. Continuous vs Continuous: Correlation
cor.test(df_cleaned$ApplicantIncome, df_cleaned$LoanAmount)
ggplot(df_cleaned, aes(x = ApplicantIncome, y = LoanAmount)) +
  geom_point(color = "blue") +
  geom_smooth(method = "lm", color = "red") +
  ggtitle("Relationship between Applicant Income and Loan Amount")

cor.test(df_cleaned$CoapplicantIncome, df_cleaned$LoanAmount)
ggplot(df_cleaned, aes(x = CoapplicantIncome, y = LoanAmount)) +
  geom_point(color = "blue") +
  geom_smooth(method = "lm", color = "red") +
  ggtitle("Relationship between Coapplicant Income and Loan Amount")

## Correlation heatmap
numeric_data <- df_cleaned[, numeric_cols]
cor_matrix <- round(cor(numeric_data, use = "complete.obs"), 2)
melted_cor <- reshape2::melt(cor_matrix)
colnames(melted_cor) <- c("Variable1", "Variable2", "Correlation")

ggplot(data = melted_cor, aes(x = Variable1, y = Variable2, fill = Correlation)) +
  geom_tile(color = "white") +
  geom_text(aes(label = round(Correlation, 2)), size = 4) +
  scale_fill_gradient2(low = "red", high = "green", mid = "white", 
                       midpoint = 0, limit = c(-1, 1), name = "Correlation") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, size = 12, hjust = 1)) +
  labs(title = "Heatmap of Numeric Variable Correlations", x = "", y = "")

## 2. Categorical + Continuous: ANOVA & Boxplot
ggplot(df_cleaned, aes(x = Property_Area, y = LoanAmount, fill = Loan_Status)) +
  geom_boxplot() +
  ggtitle("Loan Amount by Property Area and Loan Status") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

anova_test <- aov(LoanAmount ~ Property_Area * Credit_History, data = df_cleaned)
summary(anova_test)

## G. SUPERVISED LEARNING ------------------------

## 1. Logistic Regression (Simple)
# Convert Loan_Status to binary (Y = 1, N = 0)
df_cleaned$Loan_Status_Binary <- ifelse(df_cleaned$Loan_Status == "Y", 1, 0)

simple_model <- glm(Loan_Status_Binary ~ ApplicantIncome, 
                    family = binomial(link = "logit"), data = df_cleaned)
summary(simple_model)

## Plot predicted probabilities
df_cleaned$pred_prob <- predict(simple_model, type = "response")
ggplot(df_cleaned, aes(x = ApplicantIncome, y = pred_prob)) +
  geom_point(aes(color = Loan_Status), alpha = 0.5) +
  geom_smooth(method = "glm", method.args = list(family = "binomial"), color = "red") +
  ggtitle("Logistic Regression: Probability of Loan Approval vs Applicant Income") +
  ylab("Predicted Probability of Approval")

## 2. Logistic Regression (Multiple)
multi_model <- glm(Loan_Status_Binary ~ ApplicantIncome + CoapplicantIncome + 
                     LoanAmount + Credit_History, 
                   family = binomial(link = "logit"), data = df_cleaned)
summary(multi_model)

## Plot ROC curve for model evaluation
library(pROC)
roc_obj <- roc(df_cleaned$Loan_Status_Binary, predict(multi_model, type = "response"))
plot(roc_obj, main = "ROC Curve for Multiple Logistic Regression Model")
auc(roc_obj)